
document.addEventListener("DOMContentLoaded", () => {
  document.getElementById("receita").innerText = "R$ 20.000,00";
  document.getElementById("despesas").innerText = "R$ 16.789,00";
  document.getElementById("lucro").innerText = "R$ 3.211,00";
  document.getElementById("km").innerText = "1.400 km";
});
